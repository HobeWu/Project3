package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.InputValue;
import main.ConvertingApp;
import view.AppPanel;

public class MenubarListener implements ActionListener {

	
    private final AppPanel panel;
	private InputValue inputValue;

    public MenubarListener(AppPanel appPanel) {
            this.panel = appPanel;
            inputValue = new InputValue(appPanel);
            
    }

  
    @Override
    public void actionPerformed(ActionEvent e) {
            switch (e.getActionCommand()) {
                    case "SAVE":
                            float userInputInCM = Float.parseFloat(panel.getCmArea().getText().trim());
                            inputValue.updateValue(userInputInCM);
                            break;
                    default:
                            throw new RuntimeException("Invalid action command " + e.getActionCommand());
            }
    }
}
