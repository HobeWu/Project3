package main;


import javax.swing.JFrame;


import controller.MenubarListener;
import view.AppMenuBar;
import view.AppPanel;

public class ConvertingApp {
	public static void main(String[] args) {
		JFrame gameFrame = new JFrame("Converter");
		AppPanel gamePanel = new AppPanel();
		//AppListener gameListener = new AppListener(gamePanel);
		MenubarListener menubarListener = new MenubarListener(gamePanel);
		AppMenuBar AppMenuBar = new AppMenuBar(menubarListener);
		gameFrame.add(gamePanel);
		//gameFrame.addKeyListener(gameListener);
		gameFrame.setJMenuBar(AppMenuBar);
		gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameFrame.setSize(600, 600);
		gameFrame.setLocationRelativeTo(null);
		gameFrame.setResizable(false);
		gameFrame.setVisible(true);
	}

}
