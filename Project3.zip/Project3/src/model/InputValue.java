package model;

import view.AppPanel;

public class InputValue {
	double inputValue;
	private final AppPanel panel;
	public InputValue(AppPanel appPanel) {
		this.panel = appPanel;
	}
	public void updateValue(double inputValue) {
		this.inputValue = inputValue;
		notifyAreas();
	}
	private void notifyAreas() {
		panel.getFeetArea().setText(cmToFeet(inputValue) + " ft");      
        panel.getMeterArea().setText(cmToMeter(inputValue) + " m");
		
	}
	private String cmToMeter(double inputValue) {
		// TODO Auto-generated method stub
		double result = inputValue/100;
		return Double.toString(result);
	}
	private String cmToFeet(double inputValue) {
		// TODO Auto-generated method stub
		
		//return Double.toString(inputValue/30.48);
		return String.format("%.2f", inputValue/30.48).toString();
	}
}
