package view;

import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class AppMenuBar extends JMenuBar{
	public AppMenuBar(ActionListener menubarListener) {
		super();
		JMenu AppMenu = new JMenu("Update model");
		AppMenu.add(createMenuItem("Save input centimeters", "SAVE", KeyEvent.ALT_DOWN_MASK, KeyEvent.VK_F, menubarListener));
	
		super.add(AppMenu);
		
	}

	private JMenuItem createMenuItem(String text, String actionCommand, int accelerator, int accelerator2, ActionListener listener) {
		JMenuItem menuItem = new JMenuItem(text);
		menuItem.setActionCommand(actionCommand);
		menuItem.addActionListener(listener);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(accelerator2, accelerator));
		return menuItem;
	}


}
